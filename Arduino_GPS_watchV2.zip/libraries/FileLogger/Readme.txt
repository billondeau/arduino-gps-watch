FileLogger
$Id: Readme.txt 18 2009-04-22 13:57:32Z stream18 $

This is an attempt to get a tiny library for Arduino to log data into a file in a FAT16
filesystem on microSD cards 

FileLogger class is a completely new class, nanofat class is inspired by and has some code
from the microfat class developed by David Cuartielles and mmc class is basically the mmc
class developed by David Cuartielles based on previous work by Ingo Korb, Lars Pontoppidan,
Aske Olsson and Pascal Dufour.

There is an example PDE under the examples folder

Enjoy,

Eduardo Garc�a.